package com.jah.securityLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityLoginApplication.class, args);
	}

}
