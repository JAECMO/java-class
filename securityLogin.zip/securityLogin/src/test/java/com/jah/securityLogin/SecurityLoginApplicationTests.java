package com.jah.securityLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
